<?php
session_start();



$formData = $_SESSION['form_data'] ?? [];
unset($_SESSION['form_data']);
?>
<!DOCTYPE html>
<html lang="PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj użytkownika</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <form action="store_user.php" method="post">
        <label>Imię: <input type="text" name="name" value="<?= htmlspecialchars($formData['name'] ?? '')?>" required></label><br><br>
        <label>E-mail: <input type="email" name="email" value="<?= htmlspecialchars($formData['email'] ?? '')?>" required></label><br><br>
        <label>Data urodzenia: <input type="date" name="birth_date" value="<?= htmlspecialchars($formData['birth_date'] ?? '')?>" required></label><br><br>

        <label>Płeć
            <select name="gender" required>
                <option value=">-- wybierz --<"></option>
                <option value="male"><?=($formData['gender'] ?? '') === 'male' ? 'selected' : ''?>Mężczyzna</option>
                <option value="female"><?=($formData['gender'] ?? '') === 'female' ? 'selected' : ''?>Kobieta</option>
            </select>
        </label><br><br>
        <label>Opis:
            <textarea name="description" cols="50" rows="4" <?= htmlspecialchars($formData['description'])?>></textarea>


            <button type='submit'>Zapisz</button>
        </label>
        
       
    </form>
</body>
</html>



